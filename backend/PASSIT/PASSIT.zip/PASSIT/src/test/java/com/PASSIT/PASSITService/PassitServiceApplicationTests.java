package com.PASSIT.PASSITService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassitServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
